# JANSEN VALENTINE — Backend

> Boutique Management System · FastAPI + PostgreSQL + Redis + Docker

A premium asynchronous API powering the **Jansen Valentine** desktop platform — inventory, orders, customers, catalog, labels, WhatsApp, dashboard analytics and real-time WebSocket events.

---

## 🏛️ Architecture

```
                ┌──────────────────────┐
                │  Tauri Desktop App   │
                └──────────┬───────────┘
                           │  HTTPS / WS
                           ▼
                ┌──────────────────────┐
                │      Nginx (80)      │  Reverse proxy · rate limit
                └──────────┬───────────┘
                           ▼
                ┌──────────────────────┐
                │   FastAPI  (8000)    │  Async + JWT + WebSocket
                └─────┬───────────┬────┘
                      ▼           ▼
              ┌──────────────┐ ┌─────────┐
              │ PostgreSQL 16│ │ Redis 7 │
              └──────────────┘ └─────────┘
```

## 📂 Project Structure

```
backend/
├── app/
│   ├── api/v1/           # Versioned REST endpoints
│   ├── core/             # Config, security, logging
│   ├── database/         # Async SQLAlchemy session
│   ├── models/           # ORM entities
│   ├── schemas/          # Pydantic DTOs
│   ├── services/         # Business logic
│   ├── websocket/        # Real-time manager
│   └── main.py           # FastAPI app
├── alembic/              # Migrations
├── nginx/                # Reverse proxy config
├── scripts/              # Operational scripts (seed, etc.)
├── Dockerfile
├── docker-compose.yml
├── requirements.txt
└── .env.example
```

## ⚡ Quick Start

### 1. Clone & configure

```bash
cp .env.example .env
```

Open `.env` and update `SECRET_KEY`, `POSTGRES_PASSWORD`, and the admin credentials.

### 2. Build & run with Docker

```bash
docker compose up -d --build
```

The API will be live at:

| Service        | URL                              |
|----------------|----------------------------------|
| API root       | http://localhost:8000/           |
| Swagger docs   | http://localhost:8000/docs       |
| ReDoc          | http://localhost:8000/redoc      |
| Health check   | http://localhost:8000/health     |
| Behind nginx   | http://localhost/                |

### 3. Seed demo boutique data

```bash
docker compose exec api python -m scripts.seed
```

This populates the database with:
- 2 users (admin + manager)
- 7 fashion categories
- 20 sample products with variants (sizes × colors)
- 15 customers
- ~90 orders distributed across the last 30 days

### 4. Default credentials

| Role     | Email                          | Password    |
|----------|--------------------------------|-------------|
| Admin    | admin@jansenvalentine.com      | admin123    |
| Manager  | gerente@jansenvalentine.com    | gerente123  |

> **⚠️ Change these in `.env` before production deployment.**

## 🧱 Modules

| Module       | Path                            | Responsibility                                  |
|--------------|---------------------------------|-------------------------------------------------|
| Auth         | `app/api/v1/auth.py`            | Login, register, refresh, JWT                   |
| Products     | `app/api/v1/products.py`        | CRUD, variants, images, SKU generation          |
| Categories   | `app/api/v1/categories.py`      | Taxonomy management                             |
| Customers    | `app/api/v1/customers.py`       | CRM + tier engine (bronze→platinum)             |
| Orders       | `app/api/v1/orders.py`          | Lifecycle + auto stock decrement + customer KPI |
| Inventory    | `app/api/v1/inventory.py`       | Stock adjustments, low-stock alerts, audit log  |
| Catalog      | `app/api/v1/catalog.py`         | Featured products feed                          |
| Labels       | `app/api/v1/labels.py`          | PDF label sheets with QR codes                  |
| WhatsApp     | `app/api/v1/whatsapp.py`        | Quick share links + Cloud API integration       |
| Dashboard    | `app/api/v1/dashboard.py`       | Real-time KPIs and 30-day chart                 |
| Uploads      | `app/api/v1/uploads.py`         | Image uploads                                   |
| WebSocket    | `/ws`                           | Broadcast: order/stock events                   |

## 🔐 Security Layer

- **JWT (HS256)** — access + refresh tokens, role-aware claims.
- **Bcrypt** — password hashing.
- **CORS** — origin whitelist via `.env`.
- **Rate limit** — 100 req/min per IP (configurable).
- **Nginx headers** — `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`.
- **Audit trail** — every stock change is recorded in `stock_movements`.

## 📊 Database Migrations

Alembic is pre-configured. To create a new migration after changing models:

```bash
docker compose exec api alembic revision --autogenerate -m "describe change"
docker compose exec api alembic upgrade head
```

> On first boot the app auto-creates the schema via `Base.metadata.create_all` as a safety net. For production-grade deployments, use Alembic exclusively.

## 🔌 WebSocket

Connect with:

```
ws://localhost:8000/ws?token=<access_token>
```

Server pushes events of type:
- `system.welcome`
- `order.created` · `order.updated`
- `stock.updated`

Client should handle keep-alive with periodic `{"type":"ping"}`.

## 🧪 Useful Commands

```bash
# Logs
docker compose logs -f api

# Restart only the API
docker compose restart api

# Shell into the container
docker compose exec api bash

# Stop everything
docker compose down

# Wipe volumes (DANGER: deletes all data)
docker compose down -v
```

## 🚀 Production Notes

- Set `APP_ENV=production` and `APP_DEBUG=false` in `.env`.
- Replace `SECRET_KEY` with a 64+ char cryptographically random string.
- Enable HTTPS on Nginx (Let's Encrypt / Cloudflare tunnel).
- Use external managed PostgreSQL + Redis for HA.
- Configure log aggregation (Loki, Datadog, etc.).
- Set up Sentry for error tracking via env vars (extend `core/logger.py`).

## 📦 Roadmap (Phase 2 hooks already in place)

- E-commerce public storefront API
- Marketplace multi-tenant model
- Mobile app (React Native / Capacitor)
- Loyalty & coupon engine
- AI product recommendations (vector search via pgvector)
- Advanced analytics (cohort, RFM, LTV)

---

**JANSEN VALENTINE** — built by **ASTRAZ STUDIO** · Maison 2026.
