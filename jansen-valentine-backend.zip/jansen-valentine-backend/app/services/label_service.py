"""Label / tag service — generates printable PDF labels with QR codes."""
import io
import qrcode
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.product import ProductVariant, Product


def _make_qr(data: str) -> ImageReader:
    qr = qrcode.QRCode(version=1, box_size=8, border=2)
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return ImageReader(buf)


class LabelService:
    LABEL_WIDTH = 50 * mm
    LABEL_HEIGHT = 30 * mm
    MARGIN_X = 10 * mm
    MARGIN_Y = 15 * mm
    GAP_X = 4 * mm
    GAP_Y = 4 * mm

    @staticmethod
    async def generate_pdf(db: AsyncSession, variant_ids: list[int]) -> bytes:
        """Generate a PDF sheet with elegant boutique labels."""
        buf = io.BytesIO()
        c = canvas.Canvas(buf, pagesize=A4)
        page_w, page_h = A4

        cols = int((page_w - 2 * LabelService.MARGIN_X) // (LabelService.LABEL_WIDTH + LabelService.GAP_X))
        rows = int((page_h - 2 * LabelService.MARGIN_Y) // (LabelService.LABEL_HEIGHT + LabelService.GAP_Y))

        index = 0
        for vid in variant_ids:
            variant = await db.get(ProductVariant, vid)
            if not variant:
                continue
            product = await db.get(Product, variant.product_id)
            if not product:
                continue

            col = index % cols
            row = (index // cols) % rows
            x = LabelService.MARGIN_X + col * (LabelService.LABEL_WIDTH + LabelService.GAP_X)
            y = page_h - LabelService.MARGIN_Y - (row + 1) * (LabelService.LABEL_HEIGHT + LabelService.GAP_Y)

            # Label border (elegant thin line)
            c.setStrokeColorRGB(0.7, 0.7, 0.7)
            c.setLineWidth(0.4)
            c.rect(x, y, LabelService.LABEL_WIDTH, LabelService.LABEL_HEIGHT)

            # QR code
            qr_size = 22 * mm
            qr_img = _make_qr(variant.sku_variant)
            c.drawImage(qr_img, x + 2 * mm, y + 4 * mm, width=qr_size, height=qr_size)

            # Text area
            text_x = x + qr_size + 4 * mm
            c.setFillColorRGB(0.06, 0.06, 0.06)
            c.setFont("Helvetica-Bold", 7)
            c.drawString(text_x, y + LabelService.LABEL_HEIGHT - 5 * mm, "JANSEN VALENTINE")
            c.setFont("Helvetica", 6.5)
            c.drawString(text_x, y + LabelService.LABEL_HEIGHT - 9 * mm, product.name[:24])
            c.setFont("Helvetica-Bold", 9)
            c.drawString(text_x, y + LabelService.LABEL_HEIGHT - 14 * mm,
                         f"R$ {float(product.sale_price):.2f}")
            c.setFont("Helvetica", 5.5)
            details = f"{variant.size or '-'} | {variant.color or '-'}"
            c.drawString(text_x, y + LabelService.LABEL_HEIGHT - 18 * mm, details)
            c.setFont("Helvetica", 5.5)
            c.drawString(text_x, y + 3 * mm, variant.sku_variant)

            index += 1
            if index > 0 and index % (cols * rows) == 0:
                c.showPage()

        c.save()
        return buf.getvalue()
