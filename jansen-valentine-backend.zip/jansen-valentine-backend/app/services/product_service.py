"""Product service — CRUD + stock aggregation + SKU generation."""
import random
import string
from datetime import datetime
from typing import Optional
from sqlalchemy import select, func, or_
from sqlalchemy.ext.asyncio import AsyncSession
from slugify import slugify

from app.models.product import Product, ProductVariant, ProductImage
from app.models.category import Category
from app.schemas.product import ProductCreate, ProductUpdate, VariantCreate


def generate_sku(prefix: str = "JV") -> str:
    """Generate a unique-ish SKU. Format: JV-AB12C3."""
    chars = string.ascii_uppercase + string.digits
    return f"{prefix}-{''.join(random.choices(chars, k=6))}"


class ProductService:
    @staticmethod
    async def list_products(
        db: AsyncSession,
        page: int = 1,
        page_size: int = 24,
        search: str | None = None,
        category_id: int | None = None,
        is_active: bool | None = None,
    ) -> tuple[list[Product], int]:
        stmt = select(Product).order_by(Product.created_at.desc())
        if search:
            term = f"%{search.lower()}%"
            stmt = stmt.where(
                or_(
                    func.lower(Product.name).like(term),
                    func.lower(Product.sku).like(term),
                    func.lower(Product.brand).like(term),
                )
            )
        if category_id is not None:
            stmt = stmt.where(Product.category_id == category_id)
        if is_active is not None:
            stmt = stmt.where(Product.is_active == is_active)

        # Count
        count_stmt = select(func.count()).select_from(stmt.subquery())
        total = (await db.execute(count_stmt)).scalar() or 0

        # Page
        offset = (page - 1) * page_size
        stmt = stmt.offset(offset).limit(page_size)
        result = await db.execute(stmt)
        items = result.scalars().unique().all()
        return list(items), total

    @staticmethod
    async def get_product(db: AsyncSession, product_id: int) -> Optional[Product]:
        return await db.get(Product, product_id)

    @staticmethod
    async def create_product(db: AsyncSession, payload: ProductCreate) -> Product:
        sku = payload.sku or generate_sku()
        slug = slugify(f"{payload.name}-{sku}")
        product = Product(
            sku=sku,
            slug=slug,
            name=payload.name,
            description=payload.description,
            category_id=payload.category_id,
            brand=payload.brand,
            collection=payload.collection,
            cost_price=payload.cost_price,
            sale_price=payload.sale_price,
            promo_price=payload.promo_price,
            cover_image=payload.cover_image,
            tags=payload.tags,
            is_active=payload.is_active,
            is_featured=payload.is_featured,
        )
        db.add(product)
        await db.flush()

        # Create variants
        for v in payload.variants:
            variant = ProductVariant(
                product_id=product.id,
                sku_variant=f"{sku}-{(v.size or 'U').upper()}-{(v.color or 'X')[:3].upper()}-{random.randint(100, 999)}",
                size=v.size,
                color=v.color,
                color_hex=v.color_hex,
                stock_quantity=v.stock_quantity,
                low_stock_threshold=v.low_stock_threshold,
                barcode=v.barcode,
            )
            db.add(variant)

        await db.commit()
        await db.refresh(product)
        return product

    @staticmethod
    async def update_product(
        db: AsyncSession, product_id: int, payload: ProductUpdate
    ) -> Optional[Product]:
        product = await db.get(Product, product_id)
        if not product:
            return None
        data = payload.model_dump(exclude_unset=True)
        for key, value in data.items():
            setattr(product, key, value)
        if "name" in data:
            product.slug = slugify(f"{product.name}-{product.sku}")
        await db.commit()
        await db.refresh(product)
        return product

    @staticmethod
    async def delete_product(db: AsyncSession, product_id: int) -> bool:
        product = await db.get(Product, product_id)
        if not product:
            return False
        await db.delete(product)
        await db.commit()
        return True

    @staticmethod
    async def total_stock(db: AsyncSession, product_id: int) -> int:
        stmt = select(func.coalesce(func.sum(ProductVariant.stock_quantity), 0)).where(
            ProductVariant.product_id == product_id
        )
        return (await db.execute(stmt)).scalar() or 0

    @staticmethod
    async def low_stock_count(db: AsyncSession) -> int:
        stmt = select(func.count(ProductVariant.id)).where(
            ProductVariant.stock_quantity <= ProductVariant.low_stock_threshold
        )
        return (await db.execute(stmt)).scalar() or 0
