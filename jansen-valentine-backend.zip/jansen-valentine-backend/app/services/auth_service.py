"""Authentication service — login, registration, refresh."""
from datetime import datetime, timezone
from typing import Optional
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.security import (
    hash_password,
    verify_password,
    create_access_token,
    create_refresh_token,
    decode_token,
)
from app.models.user import User, UserRole
from app.schemas.auth import LoginResponse, TokenResponse, UserPublic, RegisterRequest


class AuthService:
    @staticmethod
    async def authenticate(db: AsyncSession, email: str, password: str) -> Optional[User]:
        stmt = select(User).where(User.email == email.lower())
        result = await db.execute(stmt)
        user = result.scalar_one_or_none()
        if not user or not verify_password(password, user.hashed_password):
            return None
        if not user.is_active:
            return None
        user.last_login_at = datetime.now(timezone.utc)
        await db.commit()
        await db.refresh(user)
        return user

    @staticmethod
    async def register(db: AsyncSession, payload: RegisterRequest) -> User:
        stmt = select(User).where(User.email == payload.email.lower())
        existing = await db.execute(stmt)
        if existing.scalar_one_or_none():
            raise ValueError("Email already registered")
        user = User(
            email=payload.email.lower(),
            name=payload.name,
            hashed_password=hash_password(payload.password),
            role=payload.role,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)
        return user

    @staticmethod
    def build_tokens(user: User) -> TokenResponse:
        extra = {"role": user.role, "email": user.email, "name": user.name}
        access = create_access_token(user.id, extra_claims=extra)
        refresh = create_refresh_token(user.id)
        return TokenResponse(
            access_token=access,
            refresh_token=refresh,
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        )

    @staticmethod
    def build_login_response(user: User) -> LoginResponse:
        return LoginResponse(
            user=UserPublic.model_validate(user),
            tokens=AuthService.build_tokens(user),
        )

    @staticmethod
    async def refresh_access(db: AsyncSession, refresh_token: str) -> Optional[TokenResponse]:
        payload = decode_token(refresh_token)
        if not payload or payload.get("type") != "refresh":
            return None
        user_id = int(payload.get("sub"))
        user = await db.get(User, user_id)
        if not user or not user.is_active:
            return None
        return AuthService.build_tokens(user)

    @staticmethod
    async def ensure_initial_admin(db: AsyncSession) -> None:
        """Create initial admin if no users exist."""
        result = await db.execute(select(User).limit(1))
        if result.scalar_one_or_none():
            return
        admin = User(
            email=settings.ADMIN_EMAIL.lower(),
            name=settings.ADMIN_NAME,
            hashed_password=hash_password(settings.ADMIN_PASSWORD),
            role=UserRole.ADMIN.value,
            is_active=True,
        )
        db.add(admin)
        await db.commit()
