"""Order service — orchestration of order lifecycle + stock decrement."""
from datetime import datetime, timezone
from typing import Optional
from sqlalchemy import select, func, or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.order import Order, OrderItem, OrderStatus
from app.models.product import Product, ProductVariant
from app.models.customer import Customer
from app.models.stock import StockMovement, MovementType
from app.schemas.order import OrderCreate, OrderUpdate


def generate_order_number() -> str:
    """Format: JV-20260526-XXXX (date + 4 random chars)."""
    import random, string
    suffix = "".join(random.choices(string.digits, k=4))
    return f"JV-{datetime.now().strftime('%Y%m%d')}-{suffix}"


class OrderService:
    @staticmethod
    async def list_orders(
        db: AsyncSession,
        page: int = 1,
        page_size: int = 20,
        status: str | None = None,
        customer_id: int | None = None,
        search: str | None = None,
    ) -> tuple[list[Order], int]:
        stmt = select(Order).order_by(Order.created_at.desc())
        if status:
            stmt = stmt.where(Order.status == status)
        if customer_id:
            stmt = stmt.where(Order.customer_id == customer_id)
        if search:
            stmt = stmt.where(Order.order_number.ilike(f"%{search}%"))

        count_stmt = select(func.count()).select_from(stmt.subquery())
        total = (await db.execute(count_stmt)).scalar() or 0

        offset = (page - 1) * page_size
        result = await db.execute(stmt.offset(offset).limit(page_size))
        return list(result.scalars().unique().all()), total

    @staticmethod
    async def get_order(db: AsyncSession, order_id: int) -> Optional[Order]:
        return await db.get(Order, order_id)

    @staticmethod
    async def create_order(
        db: AsyncSession, payload: OrderCreate, seller_id: int | None = None
    ) -> Order:
        order = Order(
            order_number=generate_order_number(),
            customer_id=payload.customer_id,
            seller_id=seller_id,
            status=payload.status,
            payment_method=payload.payment_method,
            discount=payload.discount,
            shipping=payload.shipping,
            notes=payload.notes,
            internal_notes=payload.internal_notes,
        )
        db.add(order)
        await db.flush()

        subtotal = 0.0
        for item_data in payload.items:
            # Pull product/variant snapshot
            variant = None
            product = None
            product_name = ""
            sku = ""
            size = None
            color = None
            if item_data.variant_id:
                variant = await db.get(ProductVariant, item_data.variant_id)
                if variant:
                    product = await db.get(Product, variant.product_id)
                    size = variant.size
                    color = variant.color
                    sku = variant.sku_variant
            if not product and item_data.product_id:
                product = await db.get(Product, item_data.product_id)
            if product:
                product_name = product.name
                sku = sku or product.sku

            line_total = (item_data.unit_price * item_data.quantity) - item_data.discount
            subtotal += line_total

            item = OrderItem(
                order_id=order.id,
                variant_id=item_data.variant_id,
                product_id=item_data.product_id or (product.id if product else None),
                product_name=product_name or "Item",
                sku=sku or "—",
                size=size,
                color=color,
                quantity=item_data.quantity,
                unit_price=item_data.unit_price,
                discount=item_data.discount,
                total=line_total,
            )
            db.add(item)

            # Decrement stock + audit
            if variant and payload.status in {"confirmed", "paid", "shipped", "delivered"}:
                before = variant.stock_quantity
                variant.stock_quantity = max(0, variant.stock_quantity - item_data.quantity)
                db.add(StockMovement(
                    variant_id=variant.id,
                    user_id=seller_id,
                    order_id=order.id,
                    type=MovementType.SALE.value,
                    quantity=-item_data.quantity,
                    quantity_before=before,
                    quantity_after=variant.stock_quantity,
                    reason=f"Order {order.order_number}",
                ))

        order.subtotal = subtotal
        order.total = max(0.0, subtotal - payload.discount + payload.shipping)
        if payload.status == "paid":
            order.paid_at = datetime.now(timezone.utc)
            order.payment_status = "paid"

        # Update customer aggregates
        if order.customer_id:
            customer = await db.get(Customer, order.customer_id)
            if customer:
                customer.total_orders = (customer.total_orders or 0) + 1
                customer.total_spent = float(customer.total_spent or 0) + order.total
                if customer.total_orders:
                    customer.avg_ticket = customer.total_spent / customer.total_orders
                # Tier rules
                if customer.total_spent >= 10000:
                    customer.tier = "platinum"
                elif customer.total_spent >= 3500:
                    customer.tier = "gold"
                elif customer.total_spent >= 1000:
                    customer.tier = "silver"

        await db.commit()
        await db.refresh(order)
        return order

    @staticmethod
    async def update_order(
        db: AsyncSession, order_id: int, payload: OrderUpdate
    ) -> Optional[Order]:
        order = await db.get(Order, order_id)
        if not order:
            return None
        data = payload.model_dump(exclude_unset=True)
        for key, value in data.items():
            setattr(order, key, value)
        if data.get("status") == "paid" and not order.paid_at:
            order.paid_at = datetime.now(timezone.utc)
            order.payment_status = "paid"
        if data.get("status") == "delivered" and not order.delivered_at:
            order.delivered_at = datetime.now(timezone.utc)
        await db.commit()
        await db.refresh(order)
        return order

    @staticmethod
    async def delete_order(db: AsyncSession, order_id: int) -> bool:
        order = await db.get(Order, order_id)
        if not order:
            return False
        await db.delete(order)
        await db.commit()
        return True
