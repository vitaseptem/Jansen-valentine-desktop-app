"""Customer CRM service."""
from typing import Optional
from sqlalchemy import select, func, or_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.customer import Customer
from app.schemas.customer import CustomerCreate, CustomerUpdate


class CustomerService:
    @staticmethod
    async def list_customers(
        db: AsyncSession,
        page: int = 1,
        page_size: int = 25,
        search: str | None = None,
        tier: str | None = None,
    ) -> tuple[list[Customer], int]:
        stmt = select(Customer).order_by(Customer.created_at.desc())
        if search:
            term = f"%{search.lower()}%"
            stmt = stmt.where(
                or_(
                    func.lower(Customer.name).like(term),
                    func.lower(Customer.email).like(term),
                    Customer.phone.like(term),
                )
            )
        if tier:
            stmt = stmt.where(Customer.tier == tier)

        count_stmt = select(func.count()).select_from(stmt.subquery())
        total = (await db.execute(count_stmt)).scalar() or 0

        offset = (page - 1) * page_size
        result = await db.execute(stmt.offset(offset).limit(page_size))
        return list(result.scalars().all()), total

    @staticmethod
    async def get_customer(db: AsyncSession, customer_id: int) -> Optional[Customer]:
        return await db.get(Customer, customer_id)

    @staticmethod
    async def create_customer(db: AsyncSession, payload: CustomerCreate) -> Customer:
        customer = Customer(**payload.model_dump())
        db.add(customer)
        await db.commit()
        await db.refresh(customer)
        return customer

    @staticmethod
    async def update_customer(
        db: AsyncSession, customer_id: int, payload: CustomerUpdate
    ) -> Optional[Customer]:
        customer = await db.get(Customer, customer_id)
        if not customer:
            return None
        for key, value in payload.model_dump(exclude_unset=True).items():
            setattr(customer, key, value)
        await db.commit()
        await db.refresh(customer)
        return customer

    @staticmethod
    async def delete_customer(db: AsyncSession, customer_id: int) -> bool:
        customer = await db.get(Customer, customer_id)
        if not customer:
            return False
        await db.delete(customer)
        await db.commit()
        return True
