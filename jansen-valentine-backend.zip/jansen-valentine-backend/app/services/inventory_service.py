"""Inventory service — stock movements & low-stock alerts."""
from typing import Optional
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.product import ProductVariant, Product
from app.models.stock import StockMovement, MovementType


class InventoryService:
    @staticmethod
    async def adjust_stock(
        db: AsyncSession,
        variant_id: int,
        delta: int,
        type_: MovementType,
        user_id: int | None = None,
        reason: str | None = None,
    ) -> Optional[ProductVariant]:
        variant = await db.get(ProductVariant, variant_id)
        if not variant:
            return None
        before = variant.stock_quantity
        variant.stock_quantity = max(0, before + delta)
        db.add(StockMovement(
            variant_id=variant.id,
            user_id=user_id,
            type=type_.value,
            quantity=delta,
            quantity_before=before,
            quantity_after=variant.stock_quantity,
            reason=reason,
        ))
        await db.commit()
        await db.refresh(variant)
        return variant

    @staticmethod
    async def low_stock_variants(db: AsyncSession, limit: int = 50) -> list:
        stmt = (
            select(ProductVariant, Product)
            .join(Product, Product.id == ProductVariant.product_id)
            .where(ProductVariant.stock_quantity <= ProductVariant.low_stock_threshold)
            .order_by(ProductVariant.stock_quantity.asc())
            .limit(limit)
        )
        result = await db.execute(stmt)
        rows = result.all()
        return [
            {
                "variant_id": v.id,
                "product_id": p.id,
                "product_name": p.name,
                "sku": v.sku_variant,
                "size": v.size,
                "color": v.color,
                "stock": v.stock_quantity,
                "threshold": v.low_stock_threshold,
            }
            for v, p in rows
        ]

    @staticmethod
    async def total_inventory_value(db: AsyncSession) -> float:
        stmt = (
            select(func.coalesce(func.sum(ProductVariant.stock_quantity * Product.cost_price), 0))
            .join(Product, Product.id == ProductVariant.product_id)
        )
        return float((await db.execute(stmt)).scalar() or 0)

    @staticmethod
    async def recent_movements(db: AsyncSession, limit: int = 30) -> list[StockMovement]:
        stmt = select(StockMovement).order_by(StockMovement.created_at.desc()).limit(limit)
        return list((await db.execute(stmt)).scalars().all())
