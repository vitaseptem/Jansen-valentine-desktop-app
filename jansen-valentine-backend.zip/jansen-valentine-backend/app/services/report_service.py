"""Report service — sales, inventory, customer reports."""
from datetime import datetime, timedelta, timezone
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.order import Order, OrderItem
from app.models.product import Product, ProductVariant
from app.models.customer import Customer
from app.schemas.common import DashboardMetrics


class ReportService:
    @staticmethod
    async def dashboard_metrics(db: AsyncSession) -> DashboardMetrics:
        now = datetime.now(timezone.utc)
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        month_start = today_start.replace(day=1)
        year_start = today_start.replace(month=1, day=1)

        async def _revenue(since: datetime) -> float:
            stmt = select(func.coalesce(func.sum(Order.total), 0)).where(
                and_(Order.created_at >= since, Order.status.in_(["paid", "delivered", "shipped"]))
            )
            return float((await db.execute(stmt)).scalar() or 0)

        revenue_today = await _revenue(today_start)
        revenue_month = await _revenue(month_start)
        revenue_year = await _revenue(year_start)

        orders_today = (await db.execute(
            select(func.count(Order.id)).where(Order.created_at >= today_start)
        )).scalar() or 0

        orders_pending = (await db.execute(
            select(func.count(Order.id)).where(Order.status.in_(["pending", "confirmed"]))
        )).scalar() or 0

        products_total = (await db.execute(select(func.count(Product.id)))).scalar() or 0

        products_low_stock = (await db.execute(
            select(func.count(ProductVariant.id)).where(
                ProductVariant.stock_quantity <= ProductVariant.low_stock_threshold
            )
        )).scalar() or 0

        customers_total = (await db.execute(select(func.count(Customer.id)))).scalar() or 0
        customers_new_month = (await db.execute(
            select(func.count(Customer.id)).where(Customer.created_at >= month_start)
        )).scalar() or 0

        avg_ticket_stmt = select(func.coalesce(func.avg(Order.total), 0)).where(
            Order.status.in_(["paid", "delivered"])
        )
        avg_ticket = float((await db.execute(avg_ticket_stmt)).scalar() or 0)

        # Top products (last 30 days)
        thirty_ago = now - timedelta(days=30)
        top_stmt = (
            select(
                OrderItem.product_name,
                OrderItem.sku,
                func.sum(OrderItem.quantity).label("qty"),
                func.sum(OrderItem.total).label("revenue"),
            )
            .join(Order, Order.id == OrderItem.order_id)
            .where(Order.created_at >= thirty_ago)
            .group_by(OrderItem.product_name, OrderItem.sku)
            .order_by(func.sum(OrderItem.quantity).desc())
            .limit(6)
        )
        top_products = [
            {"name": r.product_name, "sku": r.sku, "quantity": int(r.qty or 0), "revenue": float(r.revenue or 0)}
            for r in (await db.execute(top_stmt)).all()
        ]

        # Recent orders
        recent_stmt = select(Order).order_by(Order.created_at.desc()).limit(8)
        recent_orders = [
            {
                "id": o.id,
                "order_number": o.order_number,
                "total": float(o.total),
                "status": o.status,
                "created_at": o.created_at.isoformat(),
            }
            for o in (await db.execute(recent_stmt)).scalars().all()
        ]

        # Sales chart: last 30 days
        sales_chart = []
        for i in range(29, -1, -1):
            day = today_start - timedelta(days=i)
            day_end = day + timedelta(days=1)
            day_revenue = float((await db.execute(
                select(func.coalesce(func.sum(Order.total), 0)).where(
                    and_(Order.created_at >= day, Order.created_at < day_end,
                         Order.status.in_(["paid", "delivered", "shipped"]))
                )
            )).scalar() or 0)
            day_orders = (await db.execute(
                select(func.count(Order.id)).where(
                    and_(Order.created_at >= day, Order.created_at < day_end)
                )
            )).scalar() or 0
            sales_chart.append({
                "date": day.strftime("%Y-%m-%d"),
                "label": day.strftime("%d/%m"),
                "revenue": day_revenue,
                "orders": day_orders,
            })

        return DashboardMetrics(
            revenue_today=revenue_today,
            revenue_month=revenue_month,
            revenue_year=revenue_year,
            orders_today=orders_today,
            orders_pending=orders_pending,
            products_total=products_total,
            products_low_stock=products_low_stock,
            customers_total=customers_total,
            customers_new_month=customers_new_month,
            avg_ticket=avg_ticket,
            top_products=top_products,
            recent_orders=recent_orders,
            sales_chart=sales_chart,
        )
