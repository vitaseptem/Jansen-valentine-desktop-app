"""WhatsApp integration service.

Supports two modes:
  1. Quick share links — wa.me/<phone>?text=<message>
  2. Cloud API integration (Meta WhatsApp Business API) — optional
"""
from urllib.parse import quote
import httpx
from app.core.config import settings


class WhatsAppService:
    @staticmethod
    def quick_link(phone: str, message: str) -> str:
        """Generate a wa.me share link. Phone in international format (no + or spaces)."""
        clean_phone = "".join(filter(str.isdigit, phone))
        return f"https://wa.me/{clean_phone}?text={quote(message)}"

    @staticmethod
    def product_share_message(product_name: str, sale_price: float, url: str | None = None) -> str:
        lines = [
            "✨ *JANSEN VALENTINE*",
            "",
            f"*{product_name}*",
            f"R$ {sale_price:.2f}",
        ]
        if url:
            lines.append("")
            lines.append(url)
        return "\n".join(lines)

    @staticmethod
    def order_confirmation_message(order_number: str, customer_name: str, total: float) -> str:
        return (
            f"Olá, {customer_name}! 🌸\n\n"
            f"Seu pedido *{order_number}* foi confirmado pela JANSEN VALENTINE.\n"
            f"Valor total: *R$ {total:.2f}*\n\n"
            "Em breve entraremos em contato com mais detalhes.\n"
            "Obrigada pela preferência! ✨"
        )

    @staticmethod
    async def send_via_cloud_api(phone: str, message: str) -> dict:
        """Send a message through Meta's WhatsApp Cloud API if configured."""
        if not (settings.WHATSAPP_API_URL and settings.WHATSAPP_API_TOKEN and settings.WHATSAPP_PHONE_ID):
            return {"sent": False, "reason": "WhatsApp Cloud API not configured"}
        url = f"{settings.WHATSAPP_API_URL}/{settings.WHATSAPP_PHONE_ID}/messages"
        headers = {
            "Authorization": f"Bearer {settings.WHATSAPP_API_TOKEN}",
            "Content-Type": "application/json",
        }
        payload = {
            "messaging_product": "whatsapp",
            "to": "".join(filter(str.isdigit, phone)),
            "type": "text",
            "text": {"body": message},
        }
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.post(url, json=payload, headers=headers)
            return {"sent": r.status_code < 300, "status": r.status_code, "response": r.json()}
