"""
────────────────────────────────────────────────────────────
 JANSEN VALENTINE — Boutique Management System
 FastAPI Application Entry Point
────────────────────────────────────────────────────────────
"""
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

import redis.asyncio as aioredis
from fastapi import FastAPI, WebSocket, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from slowapi import Limiter
from slowapi.middleware import SlowAPIMiddleware
from slowapi.util import get_remote_address
from sqlalchemy import text

from app.core.config import settings
from app.core.logger import configure_logger, logger
from app.database.session import engine, AsyncSessionLocal, Base
from app.api.v1 import api_router
from app.services.auth_service import AuthService
from app.schemas.common import HealthCheck
from app.websocket.manager import websocket_handler

# Import all models so Base.metadata sees them
from app import models  # noqa: F401


limiter = Limiter(key_func=get_remote_address, default_limits=[f"{settings.RATE_LIMIT_PER_MINUTE}/minute"])


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ── STARTUP ──────────────────────────────────────────────
    configure_logger()
    logger.info(f"🌸 Booting {settings.APP_NAME} v{settings.APP_VERSION} — {settings.APP_ENV}")

    # Ensure upload dir
    Path(settings.UPLOAD_DIR).mkdir(parents=True, exist_ok=True)
    Path("logs").mkdir(parents=True, exist_ok=True)

    # Create tables (Alembic should be used in prod; this is a safety net for dev)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("✓ Database schema synchronized")

    # Bootstrap admin user
    async with AsyncSessionLocal() as db:
        await AuthService.ensure_initial_admin(db)
    logger.info("✓ Admin verification complete")

    # Redis pool
    app.state.redis = aioredis.from_url(settings.REDIS_URL, decode_responses=True)
    try:
        await app.state.redis.ping()
        logger.info("✓ Redis connection OK")
    except Exception as e:
        logger.warning(f"⚠ Redis unavailable: {e}")

    logger.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    logger.info(f"  JANSEN VALENTINE API ONLINE  →  http://0.0.0.0:{settings.APP_PORT}")
    logger.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

    yield

    # ── SHUTDOWN ─────────────────────────────────────────────
    logger.info("Shutting down…")
    if getattr(app.state, "redis", None):
        await app.state.redis.close()
    await engine.dispose()


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="Premium Boutique Management API — fashion, lingerie, beauty",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
)

app.state.limiter = limiter
app.add_middleware(SlowAPIMiddleware)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["Content-Disposition"],
)


# ── Health & Root ────────────────────────────────────────────
@app.get("/", tags=["Meta"])
async def root():
    return {
        "system": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "online",
        "docs": "/docs",
    }


@app.get("/health", response_model=HealthCheck, tags=["Meta"])
async def health():
    db_ok = False
    redis_ok = False
    try:
        async with AsyncSessionLocal() as db:
            await db.execute(text("SELECT 1"))
            db_ok = True
    except Exception:
        pass
    try:
        if getattr(app.state, "redis", None):
            await app.state.redis.ping()
            redis_ok = True
    except Exception:
        pass
    return HealthCheck(
        status="healthy" if db_ok else "degraded",
        version=settings.APP_VERSION,
        timestamp=datetime.now(timezone.utc),
        database=db_ok,
        redis=redis_ok,
    )


# ── WebSocket ────────────────────────────────────────────────
@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket, token: str | None = Query(None)):
    await websocket_handler(ws, token)


# ── Mount static uploads ────────────────────────────────────
Path(settings.UPLOAD_DIR).mkdir(parents=True, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=settings.UPLOAD_DIR), name="uploads")


# ── API Routes ───────────────────────────────────────────────
app.include_router(api_router)


# ── Generic exception handler ────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(_, exc: Exception):
    logger.exception(f"Unhandled error: {exc}")
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "type": exc.__class__.__name__},
    )
