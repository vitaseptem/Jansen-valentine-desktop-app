"""Customer schemas."""
from datetime import date, datetime
from pydantic import BaseModel, EmailStr, Field


class CustomerBase(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    email: EmailStr | None = None
    phone: str | None = None
    whatsapp: str | None = None
    cpf_cnpj: str | None = None
    birthday: date | None = None
    address: str | None = None
    city: str | None = None
    state: str | None = None
    zip_code: str | None = None
    preferred_sizes: str | None = None
    preferred_colors: str | None = None
    notes: str | None = None


class CustomerCreate(CustomerBase):
    pass


class CustomerUpdate(BaseModel):
    name: str | None = None
    email: EmailStr | None = None
    phone: str | None = None
    whatsapp: str | None = None
    cpf_cnpj: str | None = None
    birthday: date | None = None
    address: str | None = None
    city: str | None = None
    state: str | None = None
    zip_code: str | None = None
    preferred_sizes: str | None = None
    preferred_colors: str | None = None
    notes: str | None = None


class CustomerOut(CustomerBase):
    id: int
    total_orders: int
    total_spent: float
    avg_ticket: float
    tier: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class CustomerList(BaseModel):
    items: list[CustomerOut]
    total: int
    page: int
    page_size: int
    pages: int
