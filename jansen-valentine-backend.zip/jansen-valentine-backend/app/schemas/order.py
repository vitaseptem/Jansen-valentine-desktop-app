"""Order schemas."""
from datetime import datetime
from pydantic import BaseModel, Field


class OrderItemBase(BaseModel):
    variant_id: int | None = None
    product_id: int | None = None
    quantity: int = Field(ge=1, default=1)
    unit_price: float = Field(ge=0)
    discount: float = Field(ge=0, default=0)


class OrderItemCreate(OrderItemBase):
    pass


class OrderItemOut(OrderItemBase):
    id: int
    product_name: str
    sku: str
    size: str | None = None
    color: str | None = None
    total: float

    class Config:
        from_attributes = True


class OrderBase(BaseModel):
    customer_id: int | None = None
    payment_method: str | None = None
    discount: float = Field(ge=0, default=0)
    shipping: float = Field(ge=0, default=0)
    notes: str | None = None
    internal_notes: str | None = None


class OrderCreate(OrderBase):
    items: list[OrderItemCreate] = []
    status: str = "pending"


class OrderUpdate(BaseModel):
    customer_id: int | None = None
    status: str | None = None
    payment_method: str | None = None
    payment_status: str | None = None
    discount: float | None = None
    shipping: float | None = None
    notes: str | None = None
    internal_notes: str | None = None


class OrderOut(OrderBase):
    id: int
    order_number: str
    status: str
    payment_status: str
    subtotal: float
    total: float
    items: list[OrderItemOut] = []
    created_at: datetime
    updated_at: datetime
    paid_at: datetime | None = None
    delivered_at: datetime | None = None

    class Config:
        from_attributes = True


class OrderList(BaseModel):
    items: list[OrderOut]
    total: int
    page: int
    page_size: int
    pages: int
