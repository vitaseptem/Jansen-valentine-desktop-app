"""Common / shared schemas."""
from datetime import datetime
from typing import Generic, TypeVar
from pydantic import BaseModel, Field

T = TypeVar("T")


class CategoryBase(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    description: str | None = None
    icon: str | None = None
    parent_id: int | None = None
    sort_order: int = 0


class CategoryCreate(CategoryBase):
    pass


class CategoryUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    icon: str | None = None
    parent_id: int | None = None
    sort_order: int | None = None


class CategoryOut(CategoryBase):
    id: int
    slug: str
    created_at: datetime

    class Config:
        from_attributes = True


class GenericResponse(BaseModel):
    success: bool = True
    message: str
    data: dict | None = None


class HealthCheck(BaseModel):
    status: str
    version: str
    timestamp: datetime
    database: bool
    redis: bool


class DashboardMetrics(BaseModel):
    """High-level KPIs for the dashboard."""
    revenue_today: float
    revenue_month: float
    revenue_year: float
    orders_today: int
    orders_pending: int
    products_total: int
    products_low_stock: int
    customers_total: int
    customers_new_month: int
    avg_ticket: float
    top_products: list[dict] = []
    recent_orders: list[dict] = []
    sales_chart: list[dict] = []  # Last 30 days sales
