"""Product and variant schemas."""
from datetime import datetime
from pydantic import BaseModel, Field


# ─── Variant ───────────────────────────────────────────────
class VariantBase(BaseModel):
    size: str | None = None
    color: str | None = None
    color_hex: str | None = None
    stock_quantity: int = Field(ge=0, default=0)
    low_stock_threshold: int = Field(ge=0, default=5)
    barcode: str | None = None


class VariantCreate(VariantBase):
    pass


class VariantUpdate(VariantBase):
    stock_quantity: int | None = None
    low_stock_threshold: int | None = None


class VariantOut(VariantBase):
    id: int
    sku_variant: str
    product_id: int
    created_at: datetime

    class Config:
        from_attributes = True


# ─── Image ─────────────────────────────────────────────────
class ImageOut(BaseModel):
    id: int
    url: str
    sort_order: int
    is_cover: bool

    class Config:
        from_attributes = True


# ─── Category Mini ─────────────────────────────────────────
class CategoryMini(BaseModel):
    id: int
    name: str
    slug: str

    class Config:
        from_attributes = True


# ─── Product ───────────────────────────────────────────────
class ProductBase(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    description: str | None = None
    category_id: int | None = None
    brand: str | None = None
    collection: str | None = None
    cost_price: float = Field(ge=0, default=0)
    sale_price: float = Field(ge=0, default=0)
    promo_price: float | None = None
    cover_image: str | None = None
    tags: str | None = None
    is_active: bool = True
    is_featured: bool = False


class ProductCreate(ProductBase):
    sku: str | None = None
    variants: list[VariantCreate] = []


class ProductUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    category_id: int | None = None
    brand: str | None = None
    collection: str | None = None
    cost_price: float | None = None
    sale_price: float | None = None
    promo_price: float | None = None
    cover_image: str | None = None
    tags: str | None = None
    is_active: bool | None = None
    is_featured: bool | None = None


class ProductOut(ProductBase):
    id: int
    sku: str
    slug: str
    category: CategoryMini | None = None
    variants: list[VariantOut] = []
    images: list[ImageOut] = []
    total_stock: int = 0
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ProductList(BaseModel):
    items: list[ProductOut]
    total: int
    page: int
    page_size: int
    pages: int
