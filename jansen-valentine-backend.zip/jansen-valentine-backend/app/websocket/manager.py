"""Realtime WebSocket manager — broadcast events to all connected clients."""
import asyncio
import json
from typing import Set
from fastapi import WebSocket, WebSocketDisconnect

from app.core.security import decode_token
from app.core.logger import logger


class ConnectionManager:
    def __init__(self) -> None:
        self._connections: Set[WebSocket] = set()
        self._lock = asyncio.Lock()

    async def connect(self, ws: WebSocket, token: str | None) -> bool:
        """Authenticate then accept the websocket connection."""
        if not token:
            await ws.close(code=4401)
            return False
        payload = decode_token(token)
        if not payload or payload.get("type") != "access":
            await ws.close(code=4401)
            return False
        await ws.accept()
        async with self._lock:
            self._connections.add(ws)
        logger.info(f"WS connected — active: {len(self._connections)}")
        return True

    async def disconnect(self, ws: WebSocket) -> None:
        async with self._lock:
            self._connections.discard(ws)
        logger.info(f"WS disconnected — active: {len(self._connections)}")

    async def broadcast(self, payload: dict) -> None:
        """Send a JSON message to all connected clients."""
        msg = json.dumps(payload)
        stale: Set[WebSocket] = set()
        async with self._lock:
            conns = list(self._connections)
        for ws in conns:
            try:
                await ws.send_text(msg)
            except Exception:
                stale.add(ws)
        if stale:
            async with self._lock:
                self._connections -= stale


ws_manager = ConnectionManager()


async def websocket_handler(ws: WebSocket, token: str | None) -> None:
    """Single entrypoint for the /ws endpoint."""
    ok = await ws_manager.connect(ws, token)
    if not ok:
        return
    try:
        await ws_manager.broadcast({"type": "system.welcome"})
        while True:
            # Keep-alive — clients can send pings or commands here
            data = await ws.receive_text()
            try:
                msg = json.loads(data)
            except json.JSONDecodeError:
                continue
            if msg.get("type") == "ping":
                await ws.send_text(json.dumps({"type": "pong"}))
    except WebSocketDisconnect:
        await ws_manager.disconnect(ws)
    except Exception as e:
        logger.error(f"WS error: {e}")
        await ws_manager.disconnect(ws)
