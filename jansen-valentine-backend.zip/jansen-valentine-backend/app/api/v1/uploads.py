"""Upload endpoints — product images."""
import os
import uuid
from pathlib import Path
import aiofiles
from fastapi import APIRouter, File, HTTPException, UploadFile, status

from app.api.deps import CurrentUser
from app.core.config import settings

router = APIRouter(prefix="/uploads", tags=["Uploads"])

ALLOWED_EXT = {".jpg", ".jpeg", ".png", ".webp", ".gif"}


@router.post("/image")
async def upload_image(_: CurrentUser, file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "No filename")
    ext = Path(file.filename).suffix.lower()
    if ext not in ALLOWED_EXT:
        raise HTTPException(status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, "Unsupported file type")

    upload_dir = Path(settings.UPLOAD_DIR)
    upload_dir.mkdir(parents=True, exist_ok=True)

    new_name = f"{uuid.uuid4().hex}{ext}"
    target = upload_dir / new_name

    size = 0
    async with aiofiles.open(target, "wb") as out:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024:
                await out.close()
                os.remove(target)
                raise HTTPException(status.HTTP_413_REQUEST_ENTITY_TOO_LARGE, "File too large")
            await out.write(chunk)

    return {
        "filename": new_name,
        "url": f"/uploads/{new_name}",
        "size": size,
    }
