"""Customer endpoints."""
import math
from fastapi import APIRouter, HTTPException, Query, status

from app.api.deps import CurrentUser, DB
from app.schemas.customer import CustomerCreate, CustomerUpdate, CustomerOut, CustomerList
from app.services.customer_service import CustomerService

router = APIRouter(prefix="/customers", tags=["Customers"])


@router.get("", response_model=CustomerList)
async def list_customers(
    db: DB,
    _: CurrentUser,
    page: int = Query(1, ge=1),
    page_size: int = Query(25, ge=1, le=100),
    search: str | None = None,
    tier: str | None = None,
) -> CustomerList:
    items, total = await CustomerService.list_customers(db, page, page_size, search, tier)
    pages = math.ceil(total / page_size) if total else 0
    return CustomerList(
        items=[CustomerOut.model_validate(c) for c in items],
        total=total, page=page, page_size=page_size, pages=pages,
    )


@router.get("/{customer_id}", response_model=CustomerOut)
async def get_customer(customer_id: int, db: DB, _: CurrentUser) -> CustomerOut:
    customer = await CustomerService.get_customer(db, customer_id)
    if not customer:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Customer not found")
    return CustomerOut.model_validate(customer)


@router.post("", response_model=CustomerOut, status_code=status.HTTP_201_CREATED)
async def create_customer(payload: CustomerCreate, db: DB, _: CurrentUser) -> CustomerOut:
    customer = await CustomerService.create_customer(db, payload)
    return CustomerOut.model_validate(customer)


@router.patch("/{customer_id}", response_model=CustomerOut)
async def update_customer(
    customer_id: int, payload: CustomerUpdate, db: DB, _: CurrentUser
) -> CustomerOut:
    customer = await CustomerService.update_customer(db, customer_id, payload)
    if not customer:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Customer not found")
    return CustomerOut.model_validate(customer)


@router.delete("/{customer_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_customer(customer_id: int, db: DB, _: CurrentUser) -> None:
    ok = await CustomerService.delete_customer(db, customer_id)
    if not ok:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Customer not found")
