"""V1 router aggregation."""
from fastapi import APIRouter

from app.api.v1 import (
    auth, products, customers, orders, catalog,
    inventory, labels, dashboard, whatsapp, categories, uploads,
)

api_router = APIRouter(prefix="/api/v1")
api_router.include_router(auth.router)
api_router.include_router(dashboard.router)
api_router.include_router(products.router)
api_router.include_router(categories.router)
api_router.include_router(customers.router)
api_router.include_router(orders.router)
api_router.include_router(catalog.router)
api_router.include_router(inventory.router)
api_router.include_router(labels.router)
api_router.include_router(whatsapp.router)
api_router.include_router(uploads.router)
