"""Product endpoints."""
import math
from fastapi import APIRouter, HTTPException, Query, status

from app.api.deps import CurrentUser, DB
from app.schemas.product import ProductCreate, ProductUpdate, ProductOut, ProductList
from app.services.product_service import ProductService

router = APIRouter(prefix="/products", tags=["Products"])


@router.get("", response_model=ProductList)
async def list_products(
    db: DB,
    _: CurrentUser,
    page: int = Query(1, ge=1),
    page_size: int = Query(24, ge=1, le=100),
    search: str | None = None,
    category_id: int | None = None,
    is_active: bool | None = None,
) -> ProductList:
    items, total = await ProductService.list_products(
        db, page=page, page_size=page_size, search=search,
        category_id=category_id, is_active=is_active,
    )
    out: list[ProductOut] = []
    for p in items:
        total_stock = sum(v.stock_quantity for v in p.variants)
        d = ProductOut.model_validate(p)
        d.total_stock = total_stock
        out.append(d)
    pages = math.ceil(total / page_size) if total else 0
    return ProductList(items=out, total=total, page=page, page_size=page_size, pages=pages)


@router.get("/{product_id}", response_model=ProductOut)
async def get_product(product_id: int, db: DB, _: CurrentUser) -> ProductOut:
    product = await ProductService.get_product(db, product_id)
    if not product:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Product not found")
    out = ProductOut.model_validate(product)
    out.total_stock = sum(v.stock_quantity for v in product.variants)
    return out


@router.post("", response_model=ProductOut, status_code=status.HTTP_201_CREATED)
async def create_product(payload: ProductCreate, db: DB, _: CurrentUser) -> ProductOut:
    product = await ProductService.create_product(db, payload)
    out = ProductOut.model_validate(product)
    out.total_stock = sum(v.stock_quantity for v in product.variants)
    return out


@router.patch("/{product_id}", response_model=ProductOut)
async def update_product(
    product_id: int, payload: ProductUpdate, db: DB, _: CurrentUser
) -> ProductOut:
    product = await ProductService.update_product(db, product_id, payload)
    if not product:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Product not found")
    out = ProductOut.model_validate(product)
    out.total_stock = sum(v.stock_quantity for v in product.variants)
    return out


@router.delete("/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_product(product_id: int, db: DB, _: CurrentUser) -> None:
    ok = await ProductService.delete_product(db, product_id)
    if not ok:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Product not found")
