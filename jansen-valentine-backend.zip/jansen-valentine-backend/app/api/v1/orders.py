"""Order endpoints."""
import math
from fastapi import APIRouter, HTTPException, Query, status

from app.api.deps import CurrentUser, DB
from app.schemas.order import OrderCreate, OrderUpdate, OrderOut, OrderList
from app.services.order_service import OrderService
from app.websocket.manager import ws_manager

router = APIRouter(prefix="/orders", tags=["Orders"])


@router.get("", response_model=OrderList)
async def list_orders(
    db: DB,
    _: CurrentUser,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    status_filter: str | None = Query(None, alias="status"),
    customer_id: int | None = None,
    search: str | None = None,
) -> OrderList:
    items, total = await OrderService.list_orders(
        db, page, page_size, status_filter, customer_id, search
    )
    pages = math.ceil(total / page_size) if total else 0
    return OrderList(
        items=[OrderOut.model_validate(o) for o in items],
        total=total, page=page, page_size=page_size, pages=pages,
    )


@router.get("/{order_id}", response_model=OrderOut)
async def get_order(order_id: int, db: DB, _: CurrentUser) -> OrderOut:
    order = await OrderService.get_order(db, order_id)
    if not order:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Order not found")
    return OrderOut.model_validate(order)


@router.post("", response_model=OrderOut, status_code=status.HTTP_201_CREATED)
async def create_order(payload: OrderCreate, db: DB, current: CurrentUser) -> OrderOut:
    order = await OrderService.create_order(db, payload, seller_id=current.id)
    await ws_manager.broadcast({
        "type": "order.created",
        "order_id": order.id,
        "order_number": order.order_number,
        "total": float(order.total),
    })
    return OrderOut.model_validate(order)


@router.patch("/{order_id}", response_model=OrderOut)
async def update_order(
    order_id: int, payload: OrderUpdate, db: DB, _: CurrentUser
) -> OrderOut:
    order = await OrderService.update_order(db, order_id, payload)
    if not order:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Order not found")
    await ws_manager.broadcast({
        "type": "order.updated",
        "order_id": order.id,
        "status": order.status,
    })
    return OrderOut.model_validate(order)


@router.delete("/{order_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_order(order_id: int, db: DB, _: CurrentUser) -> None:
    ok = await OrderService.delete_order(db, order_id)
    if not ok:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Order not found")
