"""Category endpoints."""
from fastapi import APIRouter, HTTPException, status
from sqlalchemy import select
from slugify import slugify

from app.api.deps import CurrentUser, DB
from app.models.category import Category
from app.schemas.common import CategoryCreate, CategoryUpdate, CategoryOut

router = APIRouter(prefix="/categories", tags=["Categories"])


@router.get("", response_model=list[CategoryOut])
async def list_categories(db: DB, _: CurrentUser):
    stmt = select(Category).order_by(Category.sort_order.asc(), Category.name.asc())
    return [CategoryOut.model_validate(c) for c in (await db.execute(stmt)).scalars().all()]


@router.post("", response_model=CategoryOut, status_code=status.HTTP_201_CREATED)
async def create_category(payload: CategoryCreate, db: DB, _: CurrentUser):
    cat = Category(
        name=payload.name,
        slug=slugify(payload.name),
        description=payload.description,
        icon=payload.icon,
        parent_id=payload.parent_id,
        sort_order=payload.sort_order,
    )
    db.add(cat)
    await db.commit()
    await db.refresh(cat)
    return CategoryOut.model_validate(cat)


@router.patch("/{category_id}", response_model=CategoryOut)
async def update_category(category_id: int, payload: CategoryUpdate, db: DB, _: CurrentUser):
    cat = await db.get(Category, category_id)
    if not cat:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Category not found")
    for key, value in payload.model_dump(exclude_unset=True).items():
        setattr(cat, key, value)
    if "name" in payload.model_dump(exclude_unset=True):
        cat.slug = slugify(cat.name)
    await db.commit()
    await db.refresh(cat)
    return CategoryOut.model_validate(cat)


@router.delete("/{category_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_category(category_id: int, db: DB, _: CurrentUser):
    cat = await db.get(Category, category_id)
    if not cat:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Category not found")
    await db.delete(cat)
    await db.commit()
