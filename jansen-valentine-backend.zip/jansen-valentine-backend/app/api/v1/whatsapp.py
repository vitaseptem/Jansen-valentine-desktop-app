"""WhatsApp endpoints — quick share link generators + send."""
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel

from app.api.deps import CurrentUser, DB
from app.services.whatsapp_service import WhatsAppService
from app.services.product_service import ProductService
from app.services.customer_service import CustomerService
from app.services.order_service import OrderService

router = APIRouter(prefix="/whatsapp", tags=["WhatsApp"])


class QuickLinkRequest(BaseModel):
    phone: str
    message: str


class ProductShareRequest(BaseModel):
    product_id: int
    phone: str | None = None
    extra_message: str | None = None


@router.post("/quick-link")
async def quick_link(payload: QuickLinkRequest, _: CurrentUser):
    return {"url": WhatsAppService.quick_link(payload.phone, payload.message)}


@router.post("/share-product")
async def share_product(payload: ProductShareRequest, db: DB, _: CurrentUser):
    product = await ProductService.get_product(db, payload.product_id)
    if not product:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Product not found")
    msg = WhatsAppService.product_share_message(product.name, float(product.sale_price))
    if payload.extra_message:
        msg = f"{msg}\n\n{payload.extra_message}"
    return {
        "message": msg,
        "url": WhatsAppService.quick_link(payload.phone or "", msg) if payload.phone else None,
    }


class OrderShareRequest(BaseModel):
    order_id: int


@router.post("/order-confirmation")
async def order_confirmation(payload: OrderShareRequest, db: DB, _: CurrentUser):
    order = await OrderService.get_order(db, payload.order_id)
    if not order:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Order not found")
    customer = await CustomerService.get_customer(db, order.customer_id) if order.customer_id else None
    if not customer:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Order has no associated customer")
    msg = WhatsAppService.order_confirmation_message(
        order.order_number, customer.name, float(order.total)
    )
    phone = customer.whatsapp or customer.phone or ""
    return {
        "message": msg,
        "url": WhatsAppService.quick_link(phone, msg) if phone else None,
    }
