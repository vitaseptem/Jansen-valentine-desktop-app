"""Dashboard & report endpoints."""
from fastapi import APIRouter

from app.api.deps import CurrentUser, DB
from app.services.report_service import ReportService
from app.schemas.common import DashboardMetrics

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/metrics", response_model=DashboardMetrics)
async def dashboard_metrics(db: DB, _: CurrentUser) -> DashboardMetrics:
    return await ReportService.dashboard_metrics(db)
