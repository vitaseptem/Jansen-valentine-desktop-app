"""Catalog endpoints — curated product feed for the boutique view."""
from fastapi import APIRouter, Query
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import CurrentUser, DB
from app.models.product import Product
from app.models.category import Category
from app.schemas.product import ProductOut
from app.schemas.common import CategoryOut

router = APIRouter(prefix="/catalog", tags=["Catalog"])


@router.get("/featured", response_model=list[ProductOut])
async def featured(db: DB, _: CurrentUser, limit: int = Query(12, ge=1, le=48)) -> list[ProductOut]:
    stmt = (
        select(Product)
        .where(Product.is_active == True, Product.is_featured == True)
        .order_by(Product.updated_at.desc())
        .limit(limit)
    )
    items = (await db.execute(stmt)).scalars().unique().all()
    out: list[ProductOut] = []
    for p in items:
        d = ProductOut.model_validate(p)
        d.total_stock = sum(v.stock_quantity for v in p.variants)
        out.append(d)
    return out


@router.get("/categories", response_model=list[CategoryOut])
async def categories(db: DB, _: CurrentUser) -> list[CategoryOut]:
    stmt = select(Category).order_by(Category.sort_order.asc(), Category.name.asc())
    items = (await db.execute(stmt)).scalars().all()
    return [CategoryOut.model_validate(c) for c in items]
