"""Label generation endpoint — PDF download with QR codes."""
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
import io
from pydantic import BaseModel

from app.api.deps import CurrentUser, DB
from app.services.label_service import LabelService

router = APIRouter(prefix="/labels", tags=["Labels"])


class LabelRequest(BaseModel):
    variant_ids: list[int]


@router.post("/generate")
async def generate_labels(payload: LabelRequest, db: DB, _: CurrentUser):
    pdf_bytes = await LabelService.generate_pdf(db, payload.variant_ids)
    return StreamingResponse(
        io.BytesIO(pdf_bytes),
        media_type="application/pdf",
        headers={"Content-Disposition": "attachment; filename=jansen-valentine-labels.pdf"},
    )
