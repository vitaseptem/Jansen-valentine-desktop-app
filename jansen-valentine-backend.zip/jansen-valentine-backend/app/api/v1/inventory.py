"""Inventory & stock movement endpoints."""
from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from app.api.deps import CurrentUser, DB
from app.services.inventory_service import InventoryService
from app.models.stock import MovementType
from app.websocket.manager import ws_manager

router = APIRouter(prefix="/inventory", tags=["Inventory"])


class StockAdjustRequest(BaseModel):
    variant_id: int
    delta: int = Field(..., description="Positive for entry, negative for outflow")
    type: str = Field("adjustment")
    reason: str | None = None


@router.post("/adjust")
async def adjust_stock(payload: StockAdjustRequest, db: DB, current: CurrentUser):
    try:
        movement_type = MovementType(payload.type)
    except ValueError:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Invalid movement type")
    variant = await InventoryService.adjust_stock(
        db, payload.variant_id, payload.delta, movement_type,
        user_id=current.id, reason=payload.reason
    )
    if not variant:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Variant not found")
    await ws_manager.broadcast({
        "type": "stock.updated",
        "variant_id": variant.id,
        "stock": variant.stock_quantity,
    })
    return {
        "variant_id": variant.id,
        "stock_quantity": variant.stock_quantity,
        "delta": payload.delta,
    }


@router.get("/low-stock")
async def low_stock(db: DB, _: CurrentUser, limit: int = 50):
    return await InventoryService.low_stock_variants(db, limit)


@router.get("/value")
async def inventory_value(db: DB, _: CurrentUser):
    value = await InventoryService.total_inventory_value(db)
    return {"total_value": value}


@router.get("/movements")
async def recent_movements(db: DB, _: CurrentUser, limit: int = 30):
    movements = await InventoryService.recent_movements(db, limit)
    return [
        {
            "id": m.id,
            "variant_id": m.variant_id,
            "type": m.type,
            "quantity": m.quantity,
            "quantity_before": m.quantity_before,
            "quantity_after": m.quantity_after,
            "reason": m.reason,
            "created_at": m.created_at.isoformat(),
        }
        for m in movements
    ]
