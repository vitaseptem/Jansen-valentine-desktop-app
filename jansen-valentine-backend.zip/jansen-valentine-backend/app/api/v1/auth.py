"""Auth routes — login, register, refresh, me."""
from fastapi import APIRouter, HTTPException, status

from app.api.deps import CurrentUser, DB
from app.schemas.auth import (
    LoginRequest, LoginResponse, RegisterRequest, RefreshRequest,
    TokenResponse, UserPublic
)
from app.services.auth_service import AuthService

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/login", response_model=LoginResponse)
async def login(payload: LoginRequest, db: DB) -> LoginResponse:
    user = await AuthService.authenticate(db, payload.email, payload.password)
    if not user:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid credentials")
    return AuthService.build_login_response(user)


@router.post("/register", response_model=UserPublic, status_code=status.HTTP_201_CREATED)
async def register(payload: RegisterRequest, db: DB) -> UserPublic:
    try:
        user = await AuthService.register(db, payload)
    except ValueError as e:
        raise HTTPException(status.HTTP_409_CONFLICT, str(e))
    return UserPublic.model_validate(user)


@router.post("/refresh", response_model=TokenResponse)
async def refresh(payload: RefreshRequest, db: DB) -> TokenResponse:
    tokens = await AuthService.refresh_access(db, payload.refresh_token)
    if not tokens:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid or expired refresh token")
    return tokens


@router.get("/me", response_model=UserPublic)
async def me(current: CurrentUser) -> UserPublic:
    return UserPublic.model_validate(current)
