"""
────────────────────────────────────────────────────────────
 JANSEN VALENTINE — Logging Configuration
────────────────────────────────────────────────────────────
"""
import sys
from loguru import logger
from app.core.config import settings


def configure_logger() -> None:
    """Configure structured logging via loguru."""
    logger.remove()
    log_level = "DEBUG" if settings.APP_DEBUG else "INFO"
    logger.add(
        sys.stdout,
        level=log_level,
        format=(
            "<green>{time:YYYY-MM-DD HH:mm:ss.SSS}</green> | "
            "<level>{level: <8}</level> | "
            "<cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> | "
            "<level>{message}</level>"
        ),
        backtrace=True,
        diagnose=settings.APP_DEBUG,
    )
    logger.add(
        "logs/jansen-valentine.log",
        rotation="50 MB",
        retention="30 days",
        compression="zip",
        level=log_level,
        enqueue=True,
    )


__all__ = ["logger", "configure_logger"]
