"""
────────────────────────────────────────────────────────────
 JANSEN VALENTINE — Core Configuration
 Centralized settings via Pydantic Settings
────────────────────────────────────────────────────────────
"""
from functools import lru_cache
from typing import List
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # Application
    APP_NAME: str = "JANSEN VALENTINE"
    APP_ENV: str = "development"
    APP_DEBUG: bool = True
    APP_VERSION: str = "1.0.0"
    APP_HOST: str = "0.0.0.0"
    APP_PORT: int = 8000

    # Security
    SECRET_KEY: str = "insecure-default-change-me"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30

    # Database
    DATABASE_URL: str = "postgresql+asyncpg://jansen:jansen@postgres:5432/jansen_valentine"
    DATABASE_URL_SYNC: str = "postgresql://jansen:jansen@postgres:5432/jansen_valentine"

    # Redis
    REDIS_URL: str = "redis://redis:6379/0"

    # CORS — comma-separated string parsed to list
    CORS_ORIGINS: str = "http://localhost:1420,tauri://localhost"

    # WhatsApp
    WHATSAPP_API_URL: str = ""
    WHATSAPP_API_TOKEN: str = ""
    WHATSAPP_PHONE_ID: str = ""

    # Storage
    UPLOAD_DIR: str = "/app/uploads"
    MAX_UPLOAD_SIZE_MB: int = 10

    # Rate Limiting
    RATE_LIMIT_PER_MINUTE: int = 100

    # Initial Admin
    ADMIN_EMAIL: str = "admin@jansenvalentine.com"
    ADMIN_PASSWORD: str = "admin123"
    ADMIN_NAME: str = "Boutique Administrator"

    @property
    def cors_origins_list(self) -> List[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]

    @property
    def is_production(self) -> bool:
        return self.APP_ENV.lower() == "production"


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
