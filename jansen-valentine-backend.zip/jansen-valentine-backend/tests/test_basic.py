"""Smoke tests for the API."""
import pytest


@pytest.mark.asyncio
async def test_placeholder():
    assert True
