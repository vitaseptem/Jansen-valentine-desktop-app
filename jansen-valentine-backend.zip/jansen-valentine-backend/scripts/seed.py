"""
────────────────────────────────────────────────────────────
 JANSEN VALENTINE — Demo Seed Data
 Populates the database with realistic boutique data
 Run with: python -m scripts.seed
────────────────────────────────────────────────────────────
"""
import asyncio
import random
from datetime import datetime, timedelta, timezone
from slugify import slugify

from app.database.session import AsyncSessionLocal, engine, Base
from app.core.security import hash_password
from app.services.product_service import generate_sku
from app.services.order_service import generate_order_number
from app.models import (
    User, UserRole, Category, Product, ProductVariant, ProductImage,
    Customer, Order, OrderItem, OrderStatus, PaymentMethod, StockMovement, MovementType,
)


CATEGORIES = [
    {"name": "Vestidos", "icon": "shirt"},
    {"name": "Lingerie", "icon": "heart"},
    {"name": "Moda Praia", "icon": "sun"},
    {"name": "Blusas", "icon": "feather"},
    {"name": "Calças & Saias", "icon": "scissors"},
    {"name": "Cosméticos", "icon": "sparkles"},
    {"name": "Acessórios", "icon": "gem"},
]

SAMPLE_PRODUCTS = [
    ("Vestido Midi Floral Rivière", "Vestidos", 89.00, 249.90, ["Rosa Seco", "Champagne", "Preto"], ["P", "M", "G", "GG"], True),
    ("Vestido Longo Soirée", "Vestidos", 145.00, 489.00, ["Vinho", "Preto"], ["P", "M", "G"], True),
    ("Conjunto Lingerie Belle Époque", "Lingerie", 42.00, 159.90, ["Nude", "Preto", "Vinho"], ["P", "M", "G"], True),
    ("Camisola Cetim Maison", "Lingerie", 38.00, 129.90, ["Champagne", "Preto"], ["P", "M", "G"], False),
    ("Sutiã Renda Florence", "Lingerie", 28.00, 89.90, ["Nude", "Preto", "Rosa Seco"], ["P", "M", "G", "GG"], False),
    ("Biquíni Saint-Tropez", "Moda Praia", 35.00, 119.00, ["Preto", "Vinho", "Champagne"], ["P", "M", "G"], True),
    ("Maiô Capri Decotado", "Moda Praia", 48.00, 159.00, ["Preto", "Nude"], ["P", "M", "G"], False),
    ("Saída de Praia Crochet", "Moda Praia", 52.00, 179.00, ["Branco", "Champagne"], ["Único"], False),
    ("Blusa Seda Camille", "Blusas", 65.00, 219.00, ["Champagne", "Preto", "Vinho"], ["P", "M", "G"], True),
    ("Camisa Linho Provence", "Blusas", 58.00, 189.00, ["Branco", "Areia"], ["P", "M", "G", "GG"], False),
    ("Body Renda Couture", "Blusas", 45.00, 149.00, ["Preto", "Nude"], ["P", "M", "G"], False),
    ("Calça Alfaiataria Mônaco", "Calças & Saias", 89.00, 289.00, ["Preto", "Areia", "Vinho"], ["36", "38", "40", "42"], True),
    ("Saia Midi Plissada", "Calças & Saias", 72.00, 229.00, ["Preto", "Champagne"], ["P", "M", "G"], False),
    ("Short Linho Riviera", "Calças & Saias", 48.00, 159.00, ["Branco", "Areia"], ["36", "38", "40"], False),
    ("Batom Mate Velluto", "Cosméticos", 19.00, 79.00, ["Vinho Profundo", "Rosa Antigo", "Nude"], ["Único"], True),
    ("Perfume Eau de Parfum Astraz", "Cosméticos", 95.00, 329.00, ["50ml"], ["Único"], True),
    ("Brinco Argola Dourada", "Acessórios", 38.00, 119.00, ["Dourado"], ["Único"], False),
    ("Colar Pérolas Maison", "Acessórios", 55.00, 199.00, ["Pérola Branca", "Pérola Champagne"], ["Único"], True),
    ("Bolsa Croco Premium", "Acessórios", 165.00, 549.00, ["Preto", "Vinho"], ["Único"], True),
    ("Cinto Couro Couture", "Acessórios", 42.00, 139.00, ["Preto", "Caramelo"], ["P", "M", "G"], False),
]

COLOR_HEX_MAP = {
    "Preto": "#0A0A0A", "Branco": "#F8F4ED", "Vinho": "#7B1C2E",
    "Champagne": "#C8AD7F", "Nude": "#D9B8A8", "Rosa Seco": "#C9A6A0",
    "Areia": "#C7B299", "Caramelo": "#9C6A3F", "Dourado": "#D4AF37",
    "Pérola Branca": "#F2EDE4", "Pérola Champagne": "#E6D8B5",
    "Vinho Profundo": "#5B0E1F", "Rosa Antigo": "#B57184",
    "Único": "#999999",
}

CUSTOMER_NAMES = [
    "Beatriz Almeida", "Camila Rocha", "Júlia Bernardes", "Helena Costa",
    "Mariana Vasconcelos", "Isabella Ferreira", "Sofia Mendes", "Laura Cunha",
    "Valentina Souza", "Manuela Castro", "Ana Clara Lima", "Carolina Andrade",
    "Yasmin Pereira", "Larissa Moraes", "Patrícia Aguiar",
]


async def seed():
    print("🌸 Initializing JANSEN VALENTINE seed…")

    # Ensure schema exists
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    async with AsyncSessionLocal() as db:
        # ── Users ────────────────────────────────────────────
        admin = User(
            email="admin@jansenvalentine.com",
            name="Maison Administrator",
            hashed_password=hash_password("admin123"),
            role=UserRole.ADMIN.value,
        )
        manager = User(
            email="gerente@jansenvalentine.com",
            name="Vendedora Sênior",
            hashed_password=hash_password("gerente123"),
            role=UserRole.MANAGER.value,
        )
        db.add_all([admin, manager])
        await db.flush()

        # ── Categories ───────────────────────────────────────
        cat_map: dict[str, Category] = {}
        for i, c in enumerate(CATEGORIES):
            cat = Category(
                name=c["name"], slug=slugify(c["name"]),
                icon=c["icon"], sort_order=i,
            )
            db.add(cat)
            await db.flush()
            cat_map[c["name"]] = cat

        # ── Products + Variants ──────────────────────────────
        all_variants: list[ProductVariant] = []
        all_products: list[Product] = []
        for name, cat_name, cost, sale, colors, sizes, featured in SAMPLE_PRODUCTS:
            sku = generate_sku()
            product = Product(
                sku=sku,
                slug=slugify(f"{name}-{sku}"),
                name=name,
                description=f"Peça da maison Jansen Valentine. {name}. Tecido premium, acabamento couture.",
                category_id=cat_map[cat_name].id,
                brand="Jansen Valentine",
                collection="Maison 2026",
                cost_price=cost,
                sale_price=sale,
                promo_price=None,
                is_active=True,
                is_featured=featured,
                tags=f"{cat_name.lower()},boutique,premium",
            )
            db.add(product)
            await db.flush()
            all_products.append(product)

            for color in colors:
                for size in sizes:
                    v = ProductVariant(
                        product_id=product.id,
                        sku_variant=f"{sku}-{size}-{color[:3].upper()}-{random.randint(100,999)}",
                        size=size,
                        color=color,
                        color_hex=COLOR_HEX_MAP.get(color, "#999999"),
                        stock_quantity=random.randint(0, 18),
                        low_stock_threshold=4,
                    )
                    db.add(v)
                    all_variants.append(v)

        await db.flush()

        # ── Customers ────────────────────────────────────────
        all_customers: list[Customer] = []
        for name in CUSTOMER_NAMES:
            first = name.split()[0].lower()
            c = Customer(
                name=name,
                email=f"{first}.{random.randint(10,99)}@email.com",
                phone=f"5598{random.randint(900000000, 999999999)}",
                whatsapp=f"5598{random.randint(900000000, 999999999)}",
                city="São Luís", state="MA",
                preferred_sizes=random.choice(["P", "M", "G"]),
                preferred_colors=random.choice(["Preto", "Vinho", "Champagne"]),
                tier="bronze",
            )
            db.add(c)
            all_customers.append(c)
        await db.flush()

        # ── Orders (last 30 days, realistic distribution) ────
        now = datetime.now(timezone.utc)
        for day_offset in range(30):
            day_orders = random.randint(0, 5)
            for _ in range(day_orders):
                customer = random.choice(all_customers)
                order_date = now - timedelta(days=day_offset, hours=random.randint(0, 23))

                statuses = ["paid", "delivered", "paid", "shipped", "pending"]
                status = random.choices(statuses, weights=[35, 25, 20, 10, 10])[0]

                order = Order(
                    order_number=generate_order_number(),
                    customer_id=customer.id,
                    seller_id=manager.id,
                    status=status,
                    payment_method=random.choice([m.value for m in PaymentMethod]),
                    payment_status="paid" if status in ("paid", "delivered", "shipped") else "pending",
                    created_at=order_date,
                    updated_at=order_date,
                )
                if status in ("paid", "delivered", "shipped"):
                    order.paid_at = order_date
                if status == "delivered":
                    order.delivered_at = order_date + timedelta(days=2)

                db.add(order)
                await db.flush()

                subtotal = 0.0
                num_items = random.randint(1, 4)
                picked: set[int] = set()
                for _ in range(num_items):
                    variant = random.choice(all_variants)
                    if variant.id in picked:
                        continue
                    picked.add(variant.id)
                    product = next(p for p in all_products if p.id == variant.product_id)
                    qty = random.randint(1, 2)
                    unit = float(product.sale_price)
                    line_total = unit * qty
                    subtotal += line_total
                    db.add(OrderItem(
                        order_id=order.id,
                        variant_id=variant.id,
                        product_id=product.id,
                        product_name=product.name,
                        sku=variant.sku_variant,
                        size=variant.size,
                        color=variant.color,
                        quantity=qty,
                        unit_price=unit,
                        discount=0,
                        total=line_total,
                    ))

                discount = round(subtotal * random.choice([0, 0, 0, 0.05, 0.1]), 2)
                shipping = round(random.choice([0, 0, 15, 25]), 2)
                order.subtotal = subtotal
                order.discount = discount
                order.shipping = shipping
                order.total = max(0, subtotal - discount + shipping)

                # Update customer aggregates
                if status in ("paid", "delivered", "shipped"):
                    customer.total_orders = (customer.total_orders or 0) + 1
                    customer.total_spent = float(customer.total_spent or 0) + order.total
                    customer.avg_ticket = customer.total_spent / customer.total_orders
                    if customer.total_spent >= 10000:
                        customer.tier = "platinum"
                    elif customer.total_spent >= 3500:
                        customer.tier = "gold"
                    elif customer.total_spent >= 1000:
                        customer.tier = "silver"

        await db.commit()
        print("✓ Categories seeded")
        print(f"✓ {len(SAMPLE_PRODUCTS)} products + {len(all_variants)} variants seeded")
        print(f"✓ {len(CUSTOMER_NAMES)} customers seeded")
        print("✓ ~90 orders distributed across the last 30 days")
        print()
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print("  JANSEN VALENTINE — Seed complete")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print("  admin@jansenvalentine.com  /  admin123")
        print("  gerente@jansenvalentine.com  /  gerente123")
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")


if __name__ == "__main__":
    asyncio.run(seed())
